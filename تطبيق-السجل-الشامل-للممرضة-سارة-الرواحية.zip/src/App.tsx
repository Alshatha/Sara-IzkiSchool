/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  UserCircle, 
  Database, 
  Calendar, 
  Package, 
  Building2, 
  Stethoscope, 
  FileSpreadsheet, 
  GraduationCap, 
  ClipboardList, 
  FileText, 
  Bell,
  Plus,
  Trash2,
  Save,
  Upload,
  ChevronRight,
  Menu,
  X,
  PieChart as PieChartIcon,
  BarChart as BarChartIcon,
  Image as ImageIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip, 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend 
} from 'recharts';

// --- Types ---
type Page = 'home' | 'cv' | 'school-db' | 'plans' | 'inventory' | 'building' | 'special-cases' | 'screening' | 'education' | 'visitors' | 'reports' | 'circulars';

interface SchoolData {
  principal: string;
  assistant: string;
  socialWorker: string;
  totalStudents: string;
  totalSections: string;
  studentsPerSection: string;
  adminStaff: string;
  teachingStaff: string;
  guards: string;
  busDrivers: string;
  cleaners: string;
}

interface Device {
  id: string;
  name: string;
  count: string;
  code: string;
  origin: string;
  status: string;
}

interface Medicine {
  id: string;
  name: string;
  count: string;
  expiry: string;
}

interface SpecialCase {
  id: string;
  name: string;
  grade: string;
  condition: string;
  plan: string;
}

interface EducationEvent {
  id: string;
  date: string;
  name: string;
  target: string;
  count: string;
  type: string;
  image?: string;
}

// --- Constants ---
const MONTHS = ['سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر', 'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو'];
const CONDITIONS = [
  'سكر', 'فقر دم منجلى', 'انيماء الفول', 'النحافة', 'السمنة', 'امراض القلب', 
  'امراض الكلى', 'الربو', 'امراض جلدية', 'امراض عصبية وعضلية', 'السرطان', 
  'ضعف ابصار', 'مشاكل في السمع', 'فرط الحركة', 'بطء وصعوبة تعلم', 
  'صعوبات النطق', 'متلازمة داون'
];

export default function App() {
  const [activePage, setActivePage] = useState<Page>('home');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // --- State for Data ---
  const [schoolData, setSchoolData] = useState<SchoolData>(() => {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('schoolData') : null;
    return saved ? JSON.parse(saved) : {
      principal: '', assistant: '', socialWorker: '', totalStudents: '',
      totalSections: '', studentsPerSection: '', adminStaff: '',
      teachingStaff: '', guards: '', busDrivers: '', cleaners: ''
    };
  });

  const [cv, setCv] = useState(() => (typeof window !== 'undefined' ? localStorage.getItem('cv') : '') || '');
  
  const [devices, setDevices] = useState<Device[]>(() => {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('devices') : null;
    return saved ? JSON.parse(saved) : [];
  });

  const [medicines, setMedicines] = useState<Medicine[]>(() => {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('medicines') : null;
    return saved ? JSON.parse(saved) : [];
  });

  const [specialCases, setSpecialCases] = useState<SpecialCase[]>(() => {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('specialCases') : null;
    return saved ? JSON.parse(saved) : [];
  });

  const [eduEvents, setEduEvents] = useState<EducationEvent[]>(() => {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('eduEvents') : null;
    return saved ? JSON.parse(saved) : [];
  });

  const [buildingLogs, setBuildingLogs] = useState<any[]>(() => {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('buildingLogs') : null;
    return saved ? JSON.parse(saved) : [];
  });

  // --- Persistence ---
  useEffect(() => { localStorage.setItem('schoolData', JSON.stringify(schoolData)); }, [schoolData]);
  useEffect(() => { localStorage.setItem('cv', cv); }, [cv]);
  useEffect(() => { localStorage.setItem('devices', JSON.stringify(devices)); }, [devices]);
  useEffect(() => { localStorage.setItem('medicines', JSON.stringify(medicines)); }, [medicines]);
  useEffect(() => { localStorage.setItem('specialCases', JSON.stringify(specialCases)); }, [specialCases]);
  useEffect(() => { localStorage.setItem('eduEvents', JSON.stringify(eduEvents)); }, [eduEvents]);
  useEffect(() => { localStorage.setItem('buildingLogs', JSON.stringify(buildingLogs)); }, [buildingLogs]);

  // --- Components ---

  const SidebarItem = ({ id, icon: Icon, label }: { id: Page, icon: any, label: string }) => (
    <button
      onClick={() => setActivePage(id)}
      className={`w-full flex items-center gap-3 px-4 py-3 transition-all duration-200 ${
        activePage === id ? 'nav-item-active' : 'text-slate-600 hover:bg-slate-50'
      }`}
    >
      <Icon size={20} />
      <span className="font-medium">{label}</span>
    </button>
  );

  const PageHeader = ({ title }: { title: string }) => (
    <div className="mb-8 flex justify-between items-center">
      <h1 className="text-2xl font-bold text-slate-800">{title}</h1>
      <div className="flex gap-2">
        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
          <UserCircle size={24} />
        </div>
      </div>
    </div>
  );

  // --- Render Helpers ---

  const renderHome = () => (
    <div className="flex flex-col items-center justify-center min-h-[80vh] text-center space-y-8">
      <div className="flex gap-12 items-center mb-8">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/Ministry_of_Health_Oman_Logo.png/220px-Ministry_of_Health_Oman_Logo.png" alt="وزارة الصحة" className="h-24 object-contain" referrerPolicy="no-referrer" />
        <img src="https://upload.wikimedia.org/wikipedia/ar/thumb/a/a9/Ministry_of_Education_Oman_Logo.png/220px-Ministry_of_Education_Oman_Logo.png" alt="وزارة التربية والتعليم" className="h-24 object-contain" referrerPolicy="no-referrer" />
      </div>
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-4"
      >
        <h1 className="text-5xl font-extrabold text-blue-900 tracking-tight">الملف الشامل</h1>
        <p className="text-xl text-slate-600 font-medium">مدرسة المواهب للتعليم الأساسي</p>
      </motion.div>

      <div className="glass-card p-8 max-w-2xl w-full space-y-4">
        <div className="flex flex-col items-center space-y-2">
          <span className="text-slate-500 text-sm uppercase tracking-widest">إعداد</span>
          <h2 className="text-2xl font-bold text-slate-800">ممرضة عام أولى: سارة الرواحية</h2>
        </div>
        <div className="h-px bg-slate-200 w-full" />
        <p className="text-slate-600 italic">نحو بيئة مدرسية صحية وآمنة لأبنائنا الطلبة</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl">
        <div className="glass-card p-6 flex flex-col items-center gap-3">
          <Stethoscope className="text-blue-500" size={32} />
          <span className="font-bold">رعاية صحية</span>
        </div>
        <div className="glass-card p-6 flex flex-col items-center gap-3">
          <ClipboardList className="text-green-500" size={32} />
          <span className="font-bold">متابعة دقيقة</span>
        </div>
        <div className="glass-card p-6 flex flex-col items-center gap-3">
          <GraduationCap className="text-orange-500" size={32} />
          <span className="font-bold">تثقيف مستمر</span>
        </div>
      </div>
    </div>
  );

  const renderCV = () => (
    <div className="space-y-6">
      <PageHeader title="السيرة الذاتية" />
      <div className="glass-card p-8">
        <textarea
          value={cv}
          onChange={(e) => setCv(e.target.value)}
          placeholder="اكتب سيرتك الذاتية هنا..."
          className="w-full h-[500px] p-4 border-none focus:ring-0 text-lg leading-relaxed resize-none"
        />
        <div className="mt-4 flex justify-end">
          <button className="btn-primary">
            <Save size={18} /> حفظ التغييرات
          </button>
        </div>
      </div>
    </div>
  );

  const renderSchoolDB = () => (
    <div className="space-y-6">
      <PageHeader title="قاعدة بيانات المدرسة" />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.entries(schoolData).map(([key, value]) => {
          const labels: Record<string, string> = {
            principal: 'اسم مديرة المدرسة',
            assistant: 'اسم المدير المساعد',
            socialWorker: 'اسم الاخصائي الاجتماعي',
            totalStudents: 'عدد الطلبة الاجمالي',
            totalSections: 'عدد الشعب',
            studentsPerSection: 'عدد الطلبة داخل كل شعبة',
            adminStaff: 'عدد الهيئة الادارية',
            teachingStaff: 'عدد الهيئة التدريسية',
            guards: 'عدد الحراس',
            busDrivers: 'عدد سائقي الحافلات',
            cleaners: 'عدد عمال التنظيف'
          };
          return (
            <div key={key} className="glass-card p-4 space-y-2">
              <label className="text-sm font-bold text-slate-500">{labels[key]}</label>
              <input
                type="text"
                value={value}
                onChange={(e) => setSchoolData({ ...schoolData, [key]: e.target.value })}
                className="input-field"
              />
            </div>
          );
        })}
      </div>
    </div>
  );

  const renderPlans = () => {
    const [activeTab, setActiveTab] = useState<'general' | 'edu'>('general');
    return (
      <div className="space-y-6">
        <PageHeader title="الخطط التشغيلية" />
        <div className="flex gap-4 mb-6">
          <button 
            onClick={() => setActiveTab('general')}
            className={`px-6 py-2 rounded-full font-bold transition-all ${activeTab === 'general' ? 'bg-blue-600 text-white' : 'bg-white text-slate-600'}`}
          >
            الخطة العامة للممرضة
          </button>
          <button 
            onClick={() => setActiveTab('edu')}
            className={`px-6 py-2 rounded-full font-bold transition-all ${activeTab === 'edu' ? 'bg-blue-600 text-white' : 'bg-white text-slate-600'}`}
          >
            الخطة التثقيفية
          </button>
        </div>

        <div className="glass-card p-6 overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="border-bottom border-slate-200">
                <th className="p-4 text-slate-500">الشهر</th>
                <th className="p-4 text-slate-500">الأسبوع 1</th>
                <th className="p-4 text-slate-500">الأسبوع 2</th>
                <th className="p-4 text-slate-500">الأسبوع 3</th>
                <th className="p-4 text-slate-500">الأسبوع 4</th>
                <th className="p-4 text-slate-500">المستندات</th>
              </tr>
            </thead>
            <tbody>
              {MONTHS.map((month) => (
                <tr key={month} className="border-b border-slate-100 hover:bg-slate-50/50">
                  <td className="p-4 font-bold text-blue-900">{month}</td>
                  {[1, 2, 3, 4].map(w => (
                    <td key={w} className="p-2">
                      <input type="text" className="w-full p-2 text-sm border border-slate-100 rounded focus:border-blue-300 outline-none" placeholder="..." />
                    </td>
                  ))}
                  <td className="p-4">
                    <label className="cursor-pointer text-blue-500 hover:text-blue-700">
                      <Upload size={18} />
                      <input type="file" className="hidden" />
                    </label>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const renderInventory = () => (
    <div className="space-y-8">
      <PageHeader title="عهدة المدرسة" />
      
      <section className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-slate-700 flex items-center gap-2">
            <Package className="text-blue-500" /> عهدة الأجهزة
          </h2>
          <button 
            onClick={() => setDevices([...devices, { id: Date.now().toString(), name: '', count: '', code: '', origin: '', status: '' }])}
            className="btn-primary py-1 px-4 text-sm"
          >
            <Plus size={16} /> إضافة جهاز
          </button>
        </div>
        <div className="glass-card overflow-hidden">
          <table className="w-full text-right">
            <thead className="bg-slate-50">
              <tr>
                <th className="p-4">اسم الجهاز</th>
                <th className="p-4">العدد</th>
                <th className="p-4">الرمز</th>
                <th className="p-4">بلد التصنيع</th>
                <th className="p-4">الحالة</th>
                <th className="p-4">إجراء</th>
              </tr>
            </thead>
            <tbody>
              {devices.map((device, idx) => (
                <tr key={device.id} className="border-t border-slate-100">
                  <td className="p-2"><input className="w-full p-2 border-none bg-transparent" value={device.name} onChange={(e) => {
                    const newDevices = [...devices];
                    newDevices[idx].name = e.target.value;
                    setDevices(newDevices);
                  }} /></td>
                  <td className="p-2"><input className="w-full p-2 border-none bg-transparent" value={device.count} onChange={(e) => {
                    const newDevices = [...devices];
                    newDevices[idx].count = e.target.value;
                    setDevices(newDevices);
                  }} /></td>
                  <td className="p-2"><input className="w-full p-2 border-none bg-transparent" value={device.code} onChange={(e) => {
                    const newDevices = [...devices];
                    newDevices[idx].code = e.target.value;
                    setDevices(newDevices);
                  }} /></td>
                  <td className="p-2"><input className="w-full p-2 border-none bg-transparent" value={device.origin} onChange={(e) => {
                    const newDevices = [...devices];
                    newDevices[idx].origin = e.target.value;
                    setDevices(newDevices);
                  }} /></td>
                  <td className="p-2"><input className="w-full p-2 border-none bg-transparent" value={device.status} onChange={(e) => {
                    const newDevices = [...devices];
                    newDevices[idx].status = e.target.value;
                    setDevices(newDevices);
                  }} /></td>
                  <td className="p-2">
                    <button onClick={() => setDevices(devices.filter(d => d.id !== device.id))} className="text-red-500 p-2"><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-slate-700 flex items-center gap-2">
            <Stethoscope className="text-green-500" /> عهدة الأدوية والمواد الجراحية
          </h2>
          <button 
            onClick={() => setMedicines([...medicines, { id: Date.now().toString(), name: '', count: '', expiry: '' }])}
            className="btn-primary py-1 px-4 text-sm bg-green-600 hover:bg-green-700"
          >
            <Plus size={16} /> إضافة مادة
          </button>
        </div>
        <div className="glass-card overflow-hidden">
          <table className="w-full text-right">
            <thead className="bg-slate-50">
              <tr>
                <th className="p-4">اسم الدواء/المادة</th>
                <th className="p-4">العدد</th>
                <th className="p-4">تاريخ الانتهاء</th>
                <th className="p-4">إجراء</th>
              </tr>
            </thead>
            <tbody>
              {medicines.map((med, idx) => (
                <tr key={med.id} className="border-t border-slate-100">
                  <td className="p-2"><input className="w-full p-2 border-none bg-transparent" value={med.name} onChange={(e) => {
                    const newMeds = [...medicines];
                    newMeds[idx].name = e.target.value;
                    setMedicines(newMeds);
                  }} /></td>
                  <td className="p-2"><input className="w-full p-2 border-none bg-transparent" value={med.count} onChange={(e) => {
                    const newMeds = [...medicines];
                    newMeds[idx].count = e.target.value;
                    setMedicines(newMeds);
                  }} /></td>
                  <td className="p-2"><input type="date" className="w-full p-2 border-none bg-transparent" value={med.expiry} onChange={(e) => {
                    const newMeds = [...medicines];
                    newMeds[idx].expiry = e.target.value;
                    setMedicines(newMeds);
                  }} /></td>
                  <td className="p-2">
                    <button onClick={() => setMedicines(medicines.filter(m => m.id !== med.id))} className="text-red-500 p-2"><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );

  const renderBuilding = () => {
    const items = ['خزانات المياه', 'مياه الشرب', 'فلاتر الثلاجات', 'دورات المياه', 'السلالم', 'القاعات الدراسية', 'الساحات الخارجية', 'المقصف المدرسي'];
    
    // Mock data for stats
    const statsData = items.map(item => ({
      name: item,
      value: Math.floor(Math.random() * 100)
    }));

    return (
      <div className="space-y-8">
        <PageHeader title="متابعة المبنى المدرسي" />
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="glass-card p-6 space-y-4">
            <h3 className="text-lg font-bold mb-4">سجل المتابعة اليومي</h3>
            {items.map(item => (
              <div key={item} className="flex items-center justify-between p-3 border-b border-slate-100">
                <span className="font-medium">{item}</span>
                <div className="flex gap-2">
                  <button className="w-8 h-8 rounded bg-green-100 text-green-600 flex items-center justify-center">✓</button>
                  <button className="w-8 h-8 rounded bg-red-100 text-red-600 flex items-center justify-center">✗</button>
                  <input type="text" placeholder="ملاحظات..." className="text-xs p-1 border rounded" />
                </div>
              </div>
            ))}
          </div>

          <div className="glass-card p-6 flex flex-col items-center">
            <h3 className="text-lg font-bold mb-4">إحصائية النظافة الشهرية</h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={statsData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderSpecialCases = () => {
    const stats = CONDITIONS.map(c => ({
      name: c,
      count: specialCases.filter(sc => sc.condition === c).length
    }));

    return (
      <div className="space-y-8">
        <PageHeader title="الحالات الخاصة" />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 glass-card p-6 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold">سجل متابعة الحالات المرضية</h3>
              <button 
                onClick={() => setSpecialCases([...specialCases, { id: Date.now().toString(), name: '', grade: '', condition: CONDITIONS[0], plan: '' }])}
                className="btn-primary py-1 px-4 text-sm"
              >
                <Plus size={16} /> إضافة حالة
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-right">
                <thead>
                  <tr className="text-slate-500 text-sm">
                    <th className="p-2">اسم الطالب</th>
                    <th className="p-2">الصف</th>
                    <th className="p-2">الحالة</th>
                    <th className="p-2">خطة المتابعة</th>
                    <th className="p-2">إجراء</th>
                  </tr>
                </thead>
                <tbody>
                  {specialCases.map((sc, idx) => (
                    <tr key={sc.id} className="border-t border-slate-100">
                      <td className="p-2"><input className="w-full p-1 border rounded" value={sc.name} onChange={e => {
                        const newCases = [...specialCases];
                        newCases[idx].name = e.target.value;
                        setSpecialCases(newCases);
                      }} /></td>
                      <td className="p-2"><input className="w-full p-1 border rounded" value={sc.grade} onChange={e => {
                        const newCases = [...specialCases];
                        newCases[idx].grade = e.target.value;
                        setSpecialCases(newCases);
                      }} /></td>
                      <td className="p-2">
                        <select className="w-full p-1 border rounded" value={sc.condition} onChange={e => {
                          const newCases = [...specialCases];
                          newCases[idx].condition = e.target.value;
                          setSpecialCases(newCases);
                        }}>
                          {CONDITIONS.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                      </td>
                      <td className="p-2"><textarea className="w-full p-1 border rounded text-xs" value={sc.plan} onChange={e => {
                        const newCases = [...specialCases];
                        newCases[idx].plan = e.target.value;
                        setSpecialCases(newCases);
                      }} /></td>
                      <td className="p-2">
                        <button onClick={() => setSpecialCases(specialCases.filter(c => c.id !== sc.id))} className="text-red-500"><Trash2 size={16} /></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="glass-card p-6">
            <h3 className="text-lg font-bold mb-4">إحصائية الحالات</h3>
            <div className="h-[400px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats.filter(s => s.count > 0)}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="count"
                  >
                    {stats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={`hsl(${index * 45}, 70%, 50%)`} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderEducation = () => {
    const stats = [
      { name: 'طلبة', value: eduEvents.filter(e => e.target === 'الطلبة').length },
      { name: 'هيئة إدارية/تدريسية', value: eduEvents.filter(e => e.target === 'الهيئة الإدارية والتدريسية').length },
      { name: 'أولياء أمور', value: eduEvents.filter(e => e.target === 'أولياء الأمور').length },
      { name: 'الجميع', value: eduEvents.filter(e => e.target === 'الجميع').length },
    ];

    return (
      <div className="space-y-8">
        <PageHeader title="التثقيف الصحي" />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 glass-card p-6 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold">سجل الفعاليات التثقيفية</h3>
              <button 
                onClick={() => setEduEvents([...eduEvents, { id: Date.now().toString(), date: '', name: '', target: 'الجميع', count: '', type: 'محاضرة' }])}
                className="btn-primary py-1 px-4 text-sm"
              >
                <Plus size={16} /> إضافة فعالية
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-right text-sm">
                <thead>
                  <tr className="text-slate-500">
                    <th className="p-2">التاريخ</th>
                    <th className="p-2">اسم الفعالية</th>
                    <th className="p-2">الفئة</th>
                    <th className="p-2">العدد</th>
                    <th className="p-2">النوع</th>
                    <th className="p-2">صورة</th>
                    <th className="p-2">إجراء</th>
                  </tr>
                </thead>
                <tbody>
                  {eduEvents.map((event, idx) => (
                    <tr key={event.id} className="border-t border-slate-100">
                      <td className="p-2"><input type="date" className="w-full p-1 border rounded" value={event.date} onChange={e => {
                        const newEvents = [...eduEvents];
                        newEvents[idx].date = e.target.value;
                        setEduEvents(newEvents);
                      }} /></td>
                      <td className="p-2"><input className="w-full p-1 border rounded" value={event.name} onChange={e => {
                        const newEvents = [...eduEvents];
                        newEvents[idx].name = e.target.value;
                        setEduEvents(newEvents);
                      }} /></td>
                      <td className="p-2">
                        <select className="w-full p-1 border rounded" value={event.target} onChange={e => {
                          const newEvents = [...eduEvents];
                          newEvents[idx].target = e.target.value;
                          setEduEvents(newEvents);
                        }}>
                          <option>الطلبة</option>
                          <option>الهيئة الإدارية والتدريسية</option>
                          <option>أولياء الأمور</option>
                          <option>الجميع</option>
                        </select>
                      </td>
                      <td className="p-2"><input className="w-20 p-1 border rounded" value={event.count} onChange={e => {
                        const newEvents = [...eduEvents];
                        newEvents[idx].count = e.target.value;
                        setEduEvents(newEvents);
                      }} /></td>
                      <td className="p-2">
                        <select className="w-full p-1 border rounded" value={event.type} onChange={e => {
                          const newEvents = [...eduEvents];
                          newEvents[idx].type = e.target.value;
                          setEduEvents(newEvents);
                        }}>
                          <option>طابور</option>
                          <option>محاضرة</option>
                          <option>حلقة نقاش</option>
                          <option>معرض</option>
                          <option>أخرى</option>
                        </select>
                      </td>
                      <td className="p-2">
                        <label className="cursor-pointer text-slate-400 hover:text-blue-500">
                          <ImageIcon size={18} />
                          <input type="file" className="hidden" />
                        </label>
                      </td>
                      <td className="p-2">
                        <button onClick={() => setEduEvents(eduEvents.filter(e => e.id !== event.id))} className="text-red-500"><Trash2 size={16} /></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="glass-card p-6">
            <h3 className="text-lg font-bold mb-4">إحصائية الفعاليات</h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats}>
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderFileUploadPage = (title: string, subtitle: string) => (
    <div className="space-y-6">
      <PageHeader title={title} />
      <div className="glass-card p-12 flex flex-col items-center justify-center border-2 border-dashed border-slate-200">
        <Upload size={48} className="text-slate-300 mb-4" />
        <h3 className="text-xl font-bold text-slate-700 mb-2">{subtitle}</h3>
        <p className="text-slate-500 mb-6">اسحب الملف هنا أو اضغط للاختيار</p>
        <button className="btn-primary">
          <Plus size={18} /> إضافة مستند جديد
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[1, 2, 3].map(i => (
          <div key={i} className="glass-card p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded bg-blue-50 flex items-center justify-center text-blue-600">
                <FileText size={20} />
              </div>
              <div>
                <p className="font-bold text-sm">مستند_{i}.pdf</p>
                <p className="text-xs text-slate-400">10 مارس 2026</p>
              </div>
            </div>
            <button className="text-red-400 hover:text-red-600"><Trash2 size={16} /></button>
          </div>
        ))}
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activePage) {
      case 'home': return renderHome();
      case 'cv': return renderCV();
      case 'school-db': return renderSchoolDB();
      case 'plans': return renderPlans();
      case 'inventory': return renderInventory();
      case 'building': return renderBuilding();
      case 'special-cases': return renderSpecialCases();
      case 'screening': return renderFileUploadPage('الفحص الشامل', 'إضافة ملف إكسل للفحص الشامل');
      case 'education': return renderEducation();
      case 'visitors': return renderFileUploadPage('سجل المترددين', 'إضافة سجل المترددين الشهري');
      case 'reports': return renderFileUploadPage('سجل التقارير', 'إضافة تقارير دورية');
      case 'circulars': return renderFileUploadPage('التعاميم والنشرات', 'إضافة تعاميم وزارية');
      default: return renderHome();
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-50 font-sans">
      {/* Sidebar */}
      <aside 
        className={`fixed inset-y-0 right-0 z-50 w-72 bg-white border-l border-slate-200 transition-transform duration-300 transform ${
          isSidebarOpen ? 'translate-x-0' : 'translate-x-full'
        } lg:relative lg:translate-x-0`}
      >
        <div className="h-full flex flex-col">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
                <Stethoscope size={20} />
              </div>
              <span className="font-bold text-lg text-slate-800">السجل الصحي</span>
            </div>
            <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden text-slate-400">
              <X size={20} />
            </button>
          </div>

          <nav className="flex-1 overflow-y-auto py-4">
            <SidebarItem id="home" icon={LayoutDashboard} label="الرئيسية" />
            <SidebarItem id="cv" icon={UserCircle} label="السيرة الذاتية" />
            <SidebarItem id="school-db" icon={Database} label="قاعدة البيانات" />
            <SidebarItem id="plans" icon={Calendar} label="الخطط" />
            <SidebarItem id="inventory" icon={Package} label="العهدة" />
            <SidebarItem id="building" icon={Building2} label="متابعة المبنى" />
            <SidebarItem id="special-cases" icon={Stethoscope} label="الحالات الخاصة" />
            <SidebarItem id="screening" icon={FileSpreadsheet} label="الفحص الشامل" />
            <SidebarItem id="education" icon={GraduationCap} label="التثقيف الصحي" />
            <SidebarItem id="visitors" icon={ClipboardList} label="سجل المترددين" />
            <SidebarItem id="reports" icon={FileText} label="التقارير" />
            <SidebarItem id="circulars" icon={Bell} label="التعاميم" />
          </nav>

          <div className="p-4 border-t border-slate-100">
            <div className="bg-slate-50 rounded-xl p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
                س
              </div>
              <div>
                <p className="text-sm font-bold text-slate-800">سارة الرواحية</p>
                <p className="text-xs text-slate-500">ممرضة عام أولى</p>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center px-8 lg:hidden">
          <button onClick={() => setIsSidebarOpen(true)} className="text-slate-600">
            <Menu size={24} />
          </button>
          <span className="mr-4 font-bold text-slate-800">السجل الصحي الشامل</span>
        </header>

        <div className="flex-1 p-8 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activePage}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
